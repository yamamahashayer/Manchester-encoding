/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projectc;

/**
 *
 * @author hp
 */
public class ProjectC {

    public static void main(String[] args) {
       
        Fram1 f=new Fram1();
        f.setVisible(true);
        f.setSize(760, 450);
        
     
        
        
    }
}
